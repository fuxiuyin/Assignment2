import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.github.kevinsawicki.http.HttpRequest;

import java.io.*;
import java.util.regex.*;

public class Main2013302580159
{

    public static void main(String[] args) {
        String patterString = "(.*)?@(.*)?\\.com";
        Pattern emailPatter = Pattern.compile(patterString);
        System.out.println("打开个人主页中,一般个人主页打开速度都比较慢= =");
        String url = "http://lxy.hznu.edu.cn/szdw/jszx/sxx/588231.shtml";
        System.out.println(String.format("个人主页地址:%s", url));

        String html = HttpRequest.get(url).body();
        Document document = Jsoup.parse(html);

        Element detailContent = document.getElementById("detailContent");
        Element table = detailContent.getElementById("detailMain").getElementsByTag("table").first();
        Elements ps = table.getElementsByClass("MsoNormal");
        int i = 0;
        String name = "";
        String email = "";
        String content = "";
        String position = "";
        String phone = "";
        String birthday = "";
        String sex = "";
        for (Element p : ps) {
            ++i;
            if (i == 2)
                name = p.text();
            else if (i == 4)
                sex = p.text();
            else if (i == 7)
                birthday = p.text();
            else if (i == 10)
                email = p.text();
            else if (i == 16)
                position = p.text();
            else if (i >= 18 && i <= 22)
                content = String.format("%s\n%s", content, p.text());
        }
        System.out.println(name);
        System.out.println(sex);
        System.out.println(birthday);
        System.out.println(position);
        System.out.println(content);
        Matcher emailMatcher = emailPatter.matcher(email);
        while (emailMatcher.find()) {
            System.out.println(String.format("使用\"%s\"匹配", patterString));
            System.out.println("找到邮箱:");
            System.out.println(emailMatcher.group());
        }

        System.out.println("开始写入文件");

        String path = "./result.txt";
        File file = new File(path);
        FileOutputStream out = null;
        if (!file.exists()) {
            try{
                file.createNewFile();
            }
            catch (IOException e)
            {
                System.out.println("创建文件失败");
                return;
            }
        }
        try{
            out = new FileOutputStream(file, false);
        }
        catch (FileNotFoundException ab)
        {
            System.out.println("创建文件失败");
            return;
        }
        try
        {
            StringBuffer sb = new StringBuffer();
            sb.append("UTF-8!!!!!!!\n");
            sb.append(String.format("姓名:%s\n", name));
            sb.append(String.format("性别:%s\n", sex));
            sb.append(String.format("生日:%s\n", birthday));
            sb.append(String.format("研究方向:%s\n", position));
            sb.append(String.format("邮箱:%s\n", email));
            sb.append(String.format("简介:%s\n", content));
            out.write(sb.toString().getBytes("utf-8"));
            out.close();
        }
        catch (IOException ex)
        {
            System.out.println("文件写入失败");
        }
        System.out.println("文件写入成功");
        System.out.println("文件位置:");
        System.out.println(path);
        System.out.println("文件编码:UTF-8!!!");
    }
}
